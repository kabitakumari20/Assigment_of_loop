What is meant by cache and caching?
Why we use redis 
Why do we need redis if we have databases?
Redis advantages and disadvantages.
Explain cache miss and cache hit.
