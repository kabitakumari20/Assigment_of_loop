Other (OOPS + Git + Multithreading)
OOPS overview.
What is inheritance and abstraction .
What is Git? 
What are some basic git commands?
What is a Git repository and branches? 
What is difference between Git and GitHub
What is class,id in html? What is DOM?
