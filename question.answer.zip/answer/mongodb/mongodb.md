Why is a database? Name a few examples.
Why you use MongoDB over MySQL and PostgreSQL?  MySql vs MongoDb ( or SQL/RDBMS vs NoSql). 
Compare relational and non-Relational databases and their benefits or drawbacks? 
What kind of db is MongoDb? Why do we define schema in nodejs application when working with Mongodb if it is schema-less?
What is an aggregation pipeline? What are some stages used in it?
What is a  Schema and a model in mongoose. How are they different?
Discuss some common mongoose APIs for CRUD operations.
Why do you have to use await if you want to process the result.
What are indexes?  What is the default index value set by MongoDB?
What do you mean by database indexing? 
How to link the document of one collection to a document in another collection using mongoose. Explain reference in mongoose.
What is the difference between find, findOne, findOneAndUpdate and findById APIs. 
Allso between updateOne, update and updateMany? When should you use each?