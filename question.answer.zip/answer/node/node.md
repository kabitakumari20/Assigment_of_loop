<!-- https://docs.google.com/document/d/1MWIokY_tuuj_QzJdAYTn4B5jm6MlP1i0/edit?usp=sharing&ouid=112291245781830685063&rtpof=true&sd=true -->

What is Nodejs? What is the difference between Javascript and Nodejs? 
Node js is single threaded or multi threaded? Explain in detail what that means. 
What is meant by request and response cycle in a nodejs application?
What is express? What are the benefits of using this framework?
What is Middleware? What are global and route level middlewares?
Explain about application and route based middleware?
What is the function of an express router? What is a route and route splitting?
How Nodejs is different from a multithreaded architecture?
What is .env file or environment variables? Why are they important?
What is an event loop? Explain with an example.
security  -  how would you protect your node js server?