const globalVar= 5

function outerFunction() {
    const outerVar = 15;

    function innerFunction() {
        return globalVar + outerVar // innerFunction has access to outerVar
    }

   console.log(innerFunction())
}

outerFunction()                                                                                                                                                                                                                                                                                                                                                                                                          
