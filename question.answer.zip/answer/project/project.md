Project
How do you implement authentication in your project?
Explain the flow how a user is authenticated and the prerequisite for the same (token generation and sharing with the client)
How to generate a token ? How to verify it ?
Explain URL shortener project (explain the overview, features and how using redis). What is shortid. What happens if the same long url is passed in the request twice. How can you create a unique short code without using shortid package? How is the redirection happening?
Why do we use mvc (model view controller) in projects 
Deploy your project on Heroku ?
