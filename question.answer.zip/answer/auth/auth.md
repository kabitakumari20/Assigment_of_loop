What is authentication and authorization? What is the difference between them?
What is jwt? Describe the parts of JWT? What are the benefits of using a JWT 
Why authorization is necessary?
How did you protected your Routes?
