// console.log(this);

// function greet() {
//     console.log("Hello, " + this.name);
//   }
  
//   var person = {
//     name: "John",
//     sayHello: greet
//   };
  
//   person.sayHello();  // Output: Hello, John
//=============================================================
// console.log('hello');

// async function sol() {
//   await new Promise(resolve => setTimeout(() => {
//     console.log('second hello');
//     resolve();
//   }, 2000));
  
//   console.log('third hello');
// }

// sol();

//====================================================================
// function Person(name, age, address) {
//   this.name = name;
//   this.age = age;
//   this.address = address;
// }

// const person = new Person('John', 25, '123 Main St');
// console.log(person)

//====================================================================

// let arr= [5, 6, 10]
// let secarr= arr
// secarr.push(52)
// arr.push(89)
// console.log(secarr)

//********************************************************************************/

// const person= {
//     name: "priyanka",
//     profile: "backend developer"
// }

// const x= JSON.stringify(person) 
// console.log(x)    //{"name":"priyanka","profile":"backend developer"}

// console.log(JSON.parse(x))    //{ name: 'priyanka', profile: 'backend developer' }


//********************************************************************************/

// console.log("hello")
// setTimeout(() => {
//     console.log('I am priyanka')
// }, 1000);

//********************************************************************************/

console.log(new Date().toLocaleTimeString());
