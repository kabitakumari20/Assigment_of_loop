// const regex = /hello/; // Creating a regular expression pattern

// console.log(regex.test("wohellorld"));
//*** */

// async function delayedFunction() {
//     console.log('Start');
    
//     await new Promise((resolve) => {
//       setTimeout(() => {
//         console.log('Delayed message');
//         resolve();
//       }, 2000);
//     });
  
//     console.log('End');
//   }
  
//   delayedFunction();

//****** */

// console.log("first code")

// const hello= () => {
//     console.log("second code")
// }
// setTimeout(hello, 2000)

// console.log("third code")

//********* */

// console.log("first code")

// setTimeout( () => {
//     console.log("second code")
// }, 2000)

// console.log("third code")

// setTimeout(() =>  console.log("forth code"), 1000)

//**********/

// const person= {
//     name: "priyanka",
//     profile: "backend developer",
//     company: "functionup"
// }
// console.log(Object.keys(person))
// person.class= "graduation"
// console.log(Object.values(person))
// console.log(Object.entries(person))
// console.log(person)
// console.log(person.name)

//**********/

// function Person(name, address, age) {
//     this.name= name;
//     this.address= address;
//     this.age= age
// }

// const newPerson= new Person('priyanka', 'sasaram', 23)

// console.log(newPerson.name)

//**********/

// function res(x, y, operation){
//     console.log(operation(x,y))
// }

// function operation(x, y){
//     return x+y
// }

// res(10, 20, operation)

//********************************************************************************/

// // A function that takes a callback function as an argument
// function greetUser(name, callback) {
//     console.log(`Hello, ${name}!`);
//     callback();
// }

// // Define the callback function
// function sayGoodbye() {
//     console.log("Goodbye!");
// }

// // Call the greetUser function and pass the sayGoodbye function as a callback
// greetUser("John", sayGoodbye);

//********************************************************************************/

// function sol(){
//     console.log("hello "+this.name)
// }

// const person= {
//     name: 'Priyanka',
//     greet: sol
// }

// person.greet()

//********************************************************************************/

// const person= {
//     name: 'Priyanka',
//     greet: function sol(){
//         console.log("hello "+this.name)
//     }
// }

// person.greet()

//********************************************************************************/

// function sol(x, y, z){
//     function res(){
//         return y+z
//     }
//     console.log(res())
//     return x+y
// }
// sol(10, 20, 30)
// // console.log(sol(10, 20, 30))

//********************************************************************************/

// function sol(x, y, z) {
//     function res() {
//         return y + z;
//     }

//     return {
//         sum: x + y,
//         res: res
//     };
// }

// const result1 = sol(10, 20, 30);
// console.log(result1.res()); // Output: 50
// console.log(result1.sum);   // Output: 30

// // If you want to directly log the sum without storing it in a variable, you can do this:
// console.log(sol(10, 20, 30).sum); // Output: 30

//********************************************************************************/
//********************************************************************************/

