What is javascript? How does it work?
What is an asynchronous operation ? Is Javascript synchronous or asynchronous. 
Explain async using set timeout.
JS is a single threaded or multi threaded ?
Is JS asynchronous or synchronous language ?
Difference between var let and const
What is hoisting 
What is a promise? What are the states of promises. What is promisify?
What is async await?
Difference between promise and async & await. Is async await notation preferred over promises? If so, why?
What are JavaScript Objects ? how to create them. 
How to search for a value or a key in an object? 
What is a callback function? 
What are the drawbacks of callback and what is callback hell.
What is the difference between callback and promise. How can you write the same async operation using promise and callback 
Difference between function and arrow function
Difference between i++ and ++i
What is the “this” operator?
What is the closure concept?
what is closure - with code, why is it required, it's benefits 
What is json? What do the functions json.parse and json.stringify do?
What is the difference between '==' and '===' operators? 
What is the type of operator? What is NaN?
What are set timeout and set interval functions and what is the difference between them?
What is functional scope and block scope? 
What is shallow Copy and deep Copy
What is the difference between map and filter. Explain math, the built-in javascript object, functionalities. 
What is ES6? Explain some features of ES6
Difference btw typescript & JavaScript.
what is regex?
what is first class functions
diff between primitive and reference data types
Difference between null and undefined
difference between slice and splice 
what is spread operator and rest operator
how to convert integer to string and string to integer
Explain JS Object methods like- Object. Keys, Object. Values and Object. Entries
