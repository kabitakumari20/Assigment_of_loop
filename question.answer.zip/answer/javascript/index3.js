// const numbers = [1, 2, 3, 4, 5];

// const squaredNumbers = numbers.map((value, index, array) => num ** 2);

// console.log(squaredNumbers)

//=============================================================

// let p= new Promise( (resolve, reject) => {
//     console.log('hello')
//     resolve(56)
// })

// console.log('hello one')

// console.log(p)

//=============================================================

// let p1= new Promise( (resolve, reject) => {
//     console.log("hello one")

//     setTimeout( () => {
//         console.log("hello two")
//         resolve("resolve")
//     }, 3000)
// })
// .then( () => { console.log('I am then')})
// .catch( (err) => console.log(err.message))

// console.log("hello three")

// console.log(p1)

//=============================================================

// let p1 = new Promise((resolve, reject) => {
//     console.log("hello one");

//     setTimeout(() => {
//         console.log("hello two");
//         // Simulate a rejection by calling the reject function with an error message.
//         reject(new Error("Something went wrong!"));
//     }, 3000);
// })
//     .then(() => {
//         console.log('I am then');
//     })
//     .catch((err) => console.log(err.message));

// console.log("hello three");

// console.log(p1);

//=============================================================
function createGreeter(greeting) {
    return function(name) {
      console.log(greeting + ", " + name + "!");
    };
  }

// const x= createGreeter("hello")
// x("priyanka")

createGreeter("hello")("priyanka")

