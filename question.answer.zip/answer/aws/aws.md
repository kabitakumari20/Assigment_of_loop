What is AWS and AWS S3 ? 
What are the command to push in AWS S3?
What is meant by a bucket?
Can we upload image in database w/o using AWS S3. What are the benefits of using s3 instead?


<!-- https://www.onixnet.com/insights/what-is-amazon-s3 -->
