What is an API? 
What are Rest Api?
What are rest Api ? why they are stateless?
What are the different ways to pass data to an API while requesting a Create operation? Discuss the Content-Type header in brief
Explain the GET, POST, PUT, POST and PATCH method types
DIfference between PUt and Patch
What is an HTTP status code? Discuss the popularly used codes along with their usecase.
What are http status codes? Please elaborate?

1. What is an API?
An API (Application Programming Interface) is a set of rules and protocols that allows different software applications to communicate with each other. It defines the methods and data formats used for requests and responses between the client (requester) and the server (provider) applications. APIs enable developers to access the functionality of other software components, services, or platforms, making it easier to build applications that leverage existing capabilities.

2. What are REST APIs?
REST (Representational State Transfer) is an architectural style for designing networked applications. REST APIs (or RESTful APIs) are APIs that adhere to the principles of REST. They use standard HTTP methods and follow a stateless client-server communication model. REST APIs are widely used for building web services and are popular for their simplicity, scalability, and ease of integration.

3. Why are REST APIs stateless?
REST APIs are stateless, meaning that each request from the client to the server contains all the information needed to understand and process that request. The server does not store any client-specific information between requests. This design choice improves scalability and allows for better fault tolerance. Each request can be processed independently, and server resources are not tied up by maintaining session state for each client.

4. Different ways to pass data to an API during a Create operation:
When making a Create operation request to an API, there are several ways to pass data:

- Query Parameters: Data can be appended to the URL as key-value pairs in the query string (e.g., `?key1=value1&key2=value2`). This method is commonly used for simple data.
- Request Body: Data can be included in the body of the request using formats such as JSON or XML. This method is suitable for more complex data structures.
- Form Data: For HTML form-based requests, data can be encoded and sent as form data.
- Path Parameters: Data can be included in the URL path itself as placeholders (e.g., `/users/{userId}`). Path parameters are often used to identify a specific resource.

5. Content-Type header:
The Content-Type header is used to indicate the media type (format) of the data sent in the request or response body. It specifies how the data is structured so that the recipient knows how to interpret it. Commonly used Content-Type values include:

- application/json: Indicates that the data is in JSON format.
- application/xml: Indicates that the data is in XML format.
- multipart/form-data: Used for sending binary or large files via HTTP forms.
- application/x-www-form-urlencoded: Used for sending form data in key-value pairs.

6. GET, POST, PUT, PATCH, DELETE HTTP methods:
- GET: Retrieves data from the server. It should be used for safe, idempotent operations where the request does not modify the server's state.
- POST: Submits data to the server to create a new resource. It may also be used to perform other non-idempotent operations.
- PUT: Updates or replaces an existing resource on the server. It requires sending the complete representation of the resource.
- PATCH: Partially updates an existing resource on the server. It requires sending only the changes to be applied.
- DELETE: Removes a resource from the server.

7. Difference between PUT and PATCH:
The main difference between PUT and PATCH methods lies in the way they handle updates:
- PUT: Requires sending the complete representation of the resource, including all fields, even those that haven't changed. It replaces the entire resource with the new representation.
- PATCH: Requires sending only the changes to be applied to the resource. It allows for partial updates, modifying specific fields without affecting the rest of the resource.

8. HTTP status codes:
HTTP status codes are three-digit numbers returned by the server as part

 of an HTTP response. They provide information about the status of the requested operation. Some commonly used status codes include:

- 200 OK: Indicates a successful request.
- 201 Created: Indicates a successful creation of a new resource.
- 400 Bad Request: Indicates a malformed or invalid request.
- 401 Unauthorized: Indicates that authentication is required or credentials are invalid.
- 404 Not Found: Indicates that the requested resource could not be found on the server.
- 500 Internal Server Error: Indicates an internal server error occurred.

HTTP status codes help the client understand the outcome of the request and provide appropriate handling based on the code received.